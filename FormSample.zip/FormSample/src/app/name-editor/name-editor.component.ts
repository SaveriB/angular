import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-name-editor',
  templateUrl: './name-editor.component.html',
  styleUrls: ['./name-editor.component.css']
})
export class NameEditorComponent implements OnInit {

  constructor() { }

  name = new FormControl('');
  firstName = new FormControl('John', Validators.required);
  lastName = new FormControl('Doe', Validators.required);

  profileForm = new FormGroup (
    {
      firstName : this.firstName ,
      lastName : this.lastName
    }
  );

//   profileForm = new FormGroup({
//     username: new FormControl('agustin', Validators.required),
//     city: new FormControl('Montevideo', Validators.required)
//  });

  ngOnInit() {
  }
  updateName() {
    this.name.setValue('Nancy');
  }
  submitProfile() {
    console.warn(this.profileForm.value);
  }

}
