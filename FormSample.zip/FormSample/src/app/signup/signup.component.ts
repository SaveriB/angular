import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MustMatch } from '../shared/MustMatch';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  signupForm: FormGroup;
  submitted = false;
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.signupForm = this.fb.group({
      title : ['', Validators.required],
      name : ['', Validators.required],
      surname : ['', Validators.required],
      email : ['', [Validators.required, Validators.email]],
      password : ['', [Validators.required, Validators.minLength(6)]],
      cnmfpassword : ['', Validators.required],
      acceptTerms : ['', Validators.requiredTrue]
    }, {
      validators : MustMatch('password', 'cnmfpassword')
    });
  }
  get f() {
    return this.signupForm.controls;
  }
  signup() {
    this.submitted = true;
    if (this.signupForm.invalid) {
      return;
    }
    alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.signupForm.value, null, 4));
  }
  onReset() {
    this.submitted = false;
    this.signupForm.reset();
}
}
