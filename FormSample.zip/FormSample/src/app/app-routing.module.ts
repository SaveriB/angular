import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { NameEditorComponent } from 'src/app/name-editor/name-editor.component';
import { LoginComponent } from 'src/app/login/login.component';
import { HomeComponent } from 'src/app/home/home.component';
import { SkillDetailsComponent } from 'src/app/skill-details/skill-details.component';
import { ComponentNotFoundComponent} from './component-not-found/component-not-found.component';
import { SignupComponent } from './signup/signup.component';

const routes: Routes = [
  {
    path : 'nameEditor',
    component : NameEditorComponent
  },
  {
      path : '',
      redirectTo : '/home',
      pathMatch : 'full'
  },
  {
    path : 'login',
    component : LoginComponent
  },
  {
    path : 'signup',
    component : SignupComponent
  },
  {
    path : 'home',
    component : HomeComponent
  },
  {
    path : 'skillDetails/:userID',
    component : SkillDetailsComponent
  },
  {
    path : '**',
    component : ComponentNotFoundComponent
  }
];



@NgModule({
  declarations: [],
  imports: [
    CommonModule, RouterModule.forRoot(routes)
  ],
  exports : [RouterModule]
})
export class AppRoutingModule { }
