import { AppRoutingModule } from '../app/app-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { NameEditorComponent } from './name-editor/name-editor.component';
import { ComponentNotFoundComponent } from './component-not-found/component-not-found.component';
import { HomeComponent } from './home/home.component';
import { SkillDetailsComponent } from './skill-details/skill-details.component';
import { SignupComponent } from './signup/signup.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    NameEditorComponent,
    ComponentNotFoundComponent,
    HomeComponent,
    SkillDetailsComponent,
    SignupComponent
  ],
  imports: [
    BrowserModule, ReactiveFormsModule, AppRoutingModule, HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
