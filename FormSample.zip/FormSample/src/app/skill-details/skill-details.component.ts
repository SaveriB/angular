import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { SkillService } from 'src/app/skill-details/skill.service';
import { Skill } from './skill.model';
import { HttpService } from 'src/app/http.service';
import { Observable } from 'rxjs/internal/Observable';
// import { share } from 'rxjs/operators';

@Component({
  selector: 'app-skill-details',
  templateUrl: './skill-details.component.html',
  styleUrls: ['./skill-details.component.css']
})
export class SkillDetailsComponent implements OnInit {
  user = '';
  skillForm: FormGroup;
  showSkillForm = false;
  skillObj: Skill;
  savedSkills = [];
  skll = [];
  constructor(
    private aRoute: ActivatedRoute,
    private skillService: SkillService,
    private httpService: HttpService
  ) {}
  ngOnInit() {
    this.user = this.aRoute.snapshot.paramMap.get('userID');
    console.log('in skill s : ', this.user);
    // this.skll = this.httpService.getSkills().pipe(share());
    this.httpService.getSkills().subscribe(x => {
      // tslint:disable-next-line:no-string-literal
      this.skll = x['data'];
      console.log('...... ', x);
    }, err => {});

    // console.log('...... ', this.savedSkills);
  }
  addSkillForm() {
    console.log('add form');
    this.showSkillForm = !this.showSkillForm;
    this.skillForm = new FormGroup({
      skill: new FormControl('', Validators.required),
      exp: new FormControl('', Validators.required),
      expertie: new FormControl()
    });
  }
  addNewSkill(formValue) {
    console.log('add new skill', formValue);
    // this.skillObj.skill = formValue.skill;
    // this.skillObj.exp = formValue.exp;
    // this.skillObj.expertie = formValue.expertie;

    this.skillService.setSkills(formValue, this.user);
    this.skillForm.reset();
  }
}
