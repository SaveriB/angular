import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { SkillService } from 'src/app/skill-details/skill.service';
import { Skill } from './skill.model';

@Component({
  selector: 'app-skill-details',
  templateUrl: './skill-details.component.html',
  styleUrls: ['./skill-details.component.css']
})
export class SkillDetailsComponent implements OnInit {
user = '';
  constructor(private aRoute: ActivatedRoute, private skillService: SkillService) { }
  skillForm: FormGroup;
  showSkillForm = false;
  skillObj: Skill;
  savedSkills: Skill[];
  ngOnInit() {
    this.user = this.aRoute.snapshot.paramMap.get('userID');
    console.log('in skill s : ', this.user);
    this.savedSkills = this.skillService.getSkills();
  }
  addSkillForm() {
    console.log('add form' );
    this.showSkillForm = !this.showSkillForm;
    this.skillForm = new FormGroup({
      skill: new FormControl('', Validators.required),
      exp: new FormControl('', Validators.required),
      expertie: new FormControl()
    });
  }
  addNewSkill(formValue) {
    console.log('add new skill', formValue );
    // this.skillObj.skill = formValue.skill;
    // this.skillObj.exp = formValue.exp;
    // this.skillObj.expertie = formValue.expertie;

    this.skillService.setSkills(formValue);
    this.skillForm.reset();

  }

}
