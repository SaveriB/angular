import { Injectable } from '@angular/core';
import { Skill } from './skill.model';
import { HttpService } from '../http.service';

@Injectable({
  providedIn: 'root'
})
export class SkillService {
  skills: Skill[] = [];

  constructor(private httpService: HttpService) {}

  getSkills() {
    console.log('get skills ');
    this.httpService.getSkills().subscribe(
      (data) => {
        console.log(data);
    }, (error) => {
      console.log(error);
    });
    return this.skills;
  }

  setSkills(skill: Skill) {
    console.log('set skills');
    this.skills.push(skill);
    this.httpService.insertSKills(skill).subscribe(
      (data) => {
        console.log(data);
    }, (error) => {
      console.log(error);
    });
  }
}
