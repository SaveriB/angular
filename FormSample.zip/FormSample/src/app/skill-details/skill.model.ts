export class Skill {
 skill: string;
 exp: number;
 expertie: string;
 user: string;

}
