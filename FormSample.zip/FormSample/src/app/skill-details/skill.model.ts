export class Skill {
 skill: string;
 exp: number;
 expertie: string;
 email: string;
 contactNo: string;
}
