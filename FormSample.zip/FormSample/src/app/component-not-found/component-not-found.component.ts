import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-component-not-found',
  templateUrl: './component-not-found.component.html',
  styleUrls: ['./component-not-found.component.css']
})
export class ComponentNotFoundComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
