import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpBackend } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { Skill } from 'src/app/skill-details/skill.model';

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };
  constructor(private httpClient: HttpClient) {}

  getSkills(): Observable<Skill[]> {
    return this.httpClient.get<Skill[]>('http://localhost:3000/myprofile/skill',
      this.httpOptions);
  }

  insertSKills(reqBody: any): Observable<any> {
    return this.httpClient.post('http://localhost:3000/myprofile/skill', reqBody,
      this.httpOptions);
  }
}
