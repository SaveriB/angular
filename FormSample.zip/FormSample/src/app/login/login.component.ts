import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

loginForm = new FormGroup({
  name : new FormControl('', Validators.required),
  password : new FormControl('', Validators.required)
});

  constructor(private router: Router) { }

  ngOnInit() {
  }
  login() {
    console.log('This is our user details : ', this.loginForm.value);
    const user = this.loginForm.value.name ;
    console.log('fsdgcfasd', user);
    this.router.navigate([`/skillDetails/${user}`]);
  }

}
